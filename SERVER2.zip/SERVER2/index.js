
  let sound, amplitude, cnv;


  function preload(){
    sound = loadSound('canon.mp3');
  }



  
function setup() {
  cnv = createCanvas(100,100);
  amplitude = new p5.Amplitude();


  

  // start / stop the sound when canvas is clicked
  cnv.mouseClicked(function() {
          if (sound.isPlaying() ){
            sound.stop();
          } else {
            sound.play();
          }
        });
  }


function draw() {

  let level = amplitude.getLevel();
  smooth(level);

  let size = map(level, 0, 1, 0, 180);
  ellipse(level*100, 50, 20, 20);
  size = size*2;

  $.get("http://localhost:3000", { amp:size });

  frameRate(30);
}




