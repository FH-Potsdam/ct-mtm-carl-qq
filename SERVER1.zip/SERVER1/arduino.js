const j5 = require('johnny-five');
const board = new j5.Board();

let servo = undefined;
let led = undefined;


let n = 0;
let speed = 10;


const http = require('http');

const hostname = '127.0.0.1';
const port = 3000;

let ampT = undefined;




board.on('ready', function() {
 //   const potentiometer = new j5.Sensor("A3");

    servo = new j5.Servo(9);

    function wort(amp) {
        servo.to(amp);
    }

    const server = http.createServer((req, res) => {
        ampT = req.url;
        res.statusCode = 200;
        res.setHeader('Content-Type', 'text/plain');
        res.end('Hello, World!\n');
        ampT = ampT.slice(6);
      
        ampT = parseFloat(ampT);
      
        console.log(ampT);
      
        wort(180-ampT);
      
      });




    server.listen(port, hostname, () => {
       console.log(`Server running at http://${hostname}:${port}/`);
    });
      

/*
    potentiometer.on("change", () => {
        const {value, raw} = potentiometer;
        console.log("Sensor: ");
        console.log("  value  : ", value);
        console.log("  raw    : ", raw);
        console.log("-----------------");


        let Potpercentage = 1-(value/1000);
        console.log("  percentage    : ", Potpercentage);
        console.log("-----------------");

        let ServoPos = Potpercentage*180;
        servo.to(ServoPos);

    });


    setInterval(function(){

        
        n = n + speed;
   //      servo.to(n);

   //     if (n > 180) { n = 0; }
    }, 100)
*/
    /*
    setInterval(function(){

        n = n + 20;
        if(n > 200) { n = 1 }
        led.brightness(n);


    }, 100)
    */
    this.repl.inject({
        servo
      });
      

})


// NODE INDEX JS